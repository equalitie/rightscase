<!-- var dump <?php
	$destination = $_GET['destination'];
	$vars = explode('/', $destination);
	drupal_add_css("sites/all/themes/ninesixty/styles/forms/forms.css");
	foreach ($vars as $var){
		$var = (int)$var;
		if($var>0){
			print $var;
			$caseid = $var;
		}
	}
        drupal_add_js("sites/all/themes/ninesixty/js/forms/click-limiter.js");
?>-->
<form action="<?php print $form['#action']; ?>" method="post"></form>
<div class="clear-block"></div>

<div class="case-node-form alpha grid-16">
	<div class="left-form-container grid-8 alpha">
		<div id="case-details-form-left">
			<div class = "form-case" style="display:block;">
				<?php
					
					print drupal_render($form['field_case']);
					drupal_add_js('
						$(document).ready(function(){
							$(\'#edit-field-case-nid-nid\').val("'.$caseid.'");
						});
					', 'inline');
					drupal_add_js("sites/all/themes/ninesixty/js/forms/maphack.js");
				?>
				
			</div>
			<div class = "form-int-law left-case">
				<?php print drupal_render($form['taxonomy'][5]); ?>
				<div class="form-clear" ></div>
			</div>
			<div class = "form-vio-type left-case">
				<?php print drupal_render($form['taxonomy']['tags']); ?>
				<div class="form-clear" ></div>
			</div>
			
			<div class = "form-vio-date left-case input-text">
				<?php print drupal_render($form['field_vio_date']); ?>
				<div class="form-clear" ></div>
			</div>
			<div class = "form-vio-province left-case">
				<?php print drupal_render($form['taxonomy'][3]); ?>
				<div class="form-clear" ></div>
			</div>
			<div class="case-gmap left-case">	
				<?php print drupal_render($form['field_map_ref']); ?>
				<div class="form-clear" ></div>
			</div>
			
			
			
		</div>	
	</div>
	<div class="right-form-container grid-8 omega">
		<div id="case-details-form-right">
			<div class="form-testimony">
				<?php print drupal_render($form['field_chain_of_events']); ?>
			</div>
		</div>
		
	</div>

</div>


<div class="hide-field alpha grid-16" style="display:block;">
	<?php /* assign the buttons to a variable */
$buttons = drupal_render($form['buttons']);

/* print the rest of the form, which will be without buttons because we have already 'printed'
* them when assigning them to the variable, and print the variable right after
* the rest of the form
*/
print drupal_render($form);
?>
</div>
<div class="report-field alpha grid-16">
<?php print $buttons; ?>

</div>

