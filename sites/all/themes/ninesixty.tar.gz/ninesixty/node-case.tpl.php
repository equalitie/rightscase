<?php
if($teaser){
	echo "hello";
}else{
    dprint_r($node);
    //drupal_goto($base_url."/cases/".$node->nid);
}
