
<li class ="violation-pager <?php print $fields['nid_1']->content; ?>">
    <a href="https://<?php print $_SERVER['HTTP_HOST'].'/vioLoader/'.$fields['nid_1']->content.'/'.$fields['nid']->content; ?>/actor_page">
        <?php print $fields['field_actor_name_value']->content; ?>
    </a>
</li>


