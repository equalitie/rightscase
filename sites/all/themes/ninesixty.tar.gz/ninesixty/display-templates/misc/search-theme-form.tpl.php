
  <?php print $search_form; ?>

 <div class="logout_button">
  <a href="<?php global $base_url; echo $base_url;?>/logout">
  	<img src="<?php print $base_url.'/'.$directory;?>/images/exit_button.png" />
  </a>
</div>
