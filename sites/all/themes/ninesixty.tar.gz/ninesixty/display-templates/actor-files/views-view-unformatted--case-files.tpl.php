<?php
// $Id: views-view-unformatted.tpl.php,v 1.6 2008/10/01 20:52:11 merlinofchaos Exp $
/**
 * @file views-view-unformatted.tpl.php
 * Default simple view template to display a list of rows.
 *
 * @ingroup views_templates
 */

?>
<div class = "fileTableContainer">
	<table class="file-table">
	 	<thead class="fileFixedHeader">
	 		<tr>
				<th>Actor Name</th><th>File Name</th><th>File Type</th><th>Size</th><th>Description</th>
			</tr>
		</thead>
		<tbody class = "fileScrollContent">
			<?php foreach ($rows as $id => $row): ?>
				<?php print $row; ?>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>