
<li class ="violation-pager <?php print $fields['nid_1']->content; ?>">
    <a href="https://<?php print $_SERVER['HTTP_HOST'].'/vioLoader/'.$fields['nid_1']->content.'/'.$fields['nid']->content; ?>/vio_page">
        <?php print $fields['field_vio_date_value']->content; ?>
    </a>
</li>


