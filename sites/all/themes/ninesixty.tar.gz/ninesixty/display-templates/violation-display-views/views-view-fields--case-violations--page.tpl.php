<?php
// $Id: views-view-fields.tpl.php,v 1.6 2008/09/24 22:48:21 merlinofchaos Exp $
/**
 * @file views-view-fields.tpl.php
 * Default simple view template to all the fields as a row.
 *
 * - $view: The view in use.
 * - $fields: an array of $field objects. Each one contains:
 *   - $field->content: The output of the field.
 *   - $field->raw: The raw data for the field, if it exists. This is NOT output safe.
 *   - $field->class: The safe class id to use.
 *   - $field->handler: The Views field handler object controlling this field. Do not use
 *     var_export to dump this object, as it can't handle the recursion.
 *   - $field->inline: Whether or not the field should be inline.
 *   - $field->inline_html: either div or span based on the above flag.
 *   - $field->separator: an optional separator that may appear before a field.
 * - $row: The raw result object from the query, with all data it fetched.
 *
 * @ingroup views_templates
 */

?>
<?php 
drupal_add_js($directory."/js/actor-display/violation_display.js"); 
global $base_url; 
?>

<div id="violation-container" class="grid-13 omega">
	<div class ="left-violation-content alpha grid-6">
	
		<div class="violation-details grid-6">
		<div class="vio-field-wrapper alpha grid-6">
			<div class="violation-details-label alpha omega grid-3">
				<?php print $fields['tid']->label; ?> :
			</div>
			<div class="violation-details-content omega grid-3">
				<?php print $fields['tid']->content; ?>
			</div>
		</div>
		<!--<div class="vio-field-wrapper alpha grid-6">
			<div class="violation-details-label  omega grid-3">
				<?php print $fields['field_national_law_value']->label; ?> :
			</div>
			<div class="violation-details-content alpha grid-3">
				<?php print $fields['field_national_law_value']->content; ?>
			</div>
		</div>-->
		<div class="vio-field-wrapper alpha grid-6">
			<div class="violation-details-label alpha omega grid-3">
				<?php print $fields['tid_2']->label; ?> :
			</div>
			<div class="violation-details-contentg omega grid-3">
				<?php print $fields['tid_2']->content; ?>
			</div>
		</div>
		<div class="vio-field-wrapper alpha grid-6">
			<div class="violation-details-label alpha omega grid-3">
				<?php print $fields['tid_1']->label; ?> :
			</div>
			<div class="violation-details-content  omega grid-3">
				<?php print $fields['tid_1']->content; ?>
			</div>
		</div>
		<div class="vio-field-wrapper alpha grid-6">
			<div class="violation-details-label alpha omega grid-3">
				<?php print $fields['field_vio_date_value']->label; ?> :
			</div>
			<div class="violation-details-content omega grid-3">
				<?php print $fields['field_vio_date_value']->content; ?>
			</div>
		</div>
		<div class="vio-field-wrapper alpha grid-6">
			<div class="violation-details-label alpha omega grid-3">
				<?php print $fields['field_vio_date_value2']->label; ?> :
			</div>
			<div class="violation-details-content omega grid-3">
				<?php print $fields['field_vio_date_value2']->content; ?>
			</div>
		</div>
		
	</div>
	
	</div>
	<div class ="right-actor-content omega grid-7">
		<div class="testimony-header"><?php print $fields['field_chain_of_events_value']->label ?></div>
		<div class="violation-textarea"><?php print $fields['field_chain_of_events_value']->content ?></div>
	

		<div class="button-holder">
			<div class="edit-button ">
				<?php
				
				$redirect_id = $fields['nid']->raw;
				?>
				<a href="<?php print $base_url; ?>/node/<?php echo $fields['nid_1']->content; ?>/edit?destination=<?php print urlencode('cases/'.$redirect_id.'/violations'); ?>" >Edit Violation</a>
			</div>
			<div class="edit-button ">
				<a href="<?php print $base_url; ?>/node/add/violation?destination=<?php print urlencode('cases/'.$redirect_id.'/violations'); ?>" >Add Violation</a>
			</div>
			<div class="edit-button ">
				<a href="<?php print $base_url; ?>/print<?php print $_SERVER['REDIRECT_URL']; ?>" target="_blank">
					Printer View
				</a>
			</div>
		</div>
	
	</div>
</div>



