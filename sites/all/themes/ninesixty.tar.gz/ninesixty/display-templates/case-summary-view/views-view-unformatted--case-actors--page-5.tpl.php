<?php

foreach ($rows as $id => $row) {
    $c = $classes[$id];
    echo $row;
}