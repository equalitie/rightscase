<?php
    $f = $fields;
    echo $fields['field_actor_name_value']->content;
    echo "<!--".$fields['tid_1']->content."-->"
?>
<br/>