/**
 * @author cormac1
 * views-cycle-case_actors-page_2
 */
$(document).ready(function(){

    $('.violation-pager a').click(function(event){
        event.preventDefault();
    });

    $('.violation-pager').click(function(){
        HtmlLoader.url = $(this).children().attr('href');
        HtmlLoader.loadHtmlContent();
        $(this).addClass('activeSlide');
	$(this).siblings().removeClass('activeSlide');
    });

    $( '.violation-pager:first' ).trigger( 'click' );
});


var HtmlLoader = {
    url:null,
    jsonArray:null,
    
    loadHtmlContent:function(){
        $.getJSON(this.url, this.parseJSON)
    },
    
    applyHtml: function(html){
        $('#violation-container').empty();
        $('#violation-container').append(html);
    },

    parseJSON:function(json){
        this.jsonArray = json;
        HtmlLoader.applyHtml(json['html_content']);
    }

}