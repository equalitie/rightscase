/**
 * @author cormac1
 */
$(document).ready(function(){
	var url = top.window.location.href;
	if (url.search('processing') != -1) {
	$('#report-field').hide('fast');
	$('#case-details-form-left').hide('fast');
	$('#case-details-form-right').hide('fast');
	
	}
	else if (url.search('report') != -1) {
		$('#processing-form-left').hide('fast');
	$('#processing-form-right').hide('fast');
	$('#case-details-form-left').hide('fast');
	$('#case-details-form-right').hide('fast');
	
	
	

	}else{
		$('#processing-form-left').hide('fast');
		$('#processing-form-right').hide('fast');
		$('#report-field').hide('fast');
	}
	
	$('#edit-field-map-ref-0-country').val('zw');


});