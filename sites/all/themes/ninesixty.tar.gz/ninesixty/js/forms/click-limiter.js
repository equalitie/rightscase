/**
 * @author cormac1
 */
/*$(document).ready(function(){
    $('.form-submit').click(function(){
        $(this).attr("disabled","true");
    });
});*/